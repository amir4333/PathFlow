# Utilities Layer

Shared stateless utilities, helpers, and formatting routines.

## Guidelines
* **Pure Functions**: Utilities must be side-effect free, deterministically testable, and have zero dependencies on React state or components.
* **Scope**: Formatting (e.g., duration, timestamps, strings) and UI helper functions (such as `cn.ts`).
