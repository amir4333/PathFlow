/**
 * Minimal class names utility for combining Tailwind utility classes.
 */
export function cn(...classes: (string | boolean | undefined | null)[]): string {
  return classes.filter(Boolean).join(' ');
}
