# PathFlow

A personal, multi-device, **Offline-First** system for managing long-term goals, roadmaps, tasks, work sessions, time tracking, weekly planning, progress, synchronization, and controlled progress sharing with a teacher.

> **Current Status: PHASE 1 ONLY (Project Foundation)**
> This codebase currently represents the architectural skeleton and foundation shell. No feature domain logic, database operations, or synchronization engines have been implemented yet.

---

## 1. Project Name
**PathFlow**

## 2. Short Description
PathFlow guides users through a deliberate, structured execution pipeline:
```text
Goal → Roadmap → Task → Session → Time → Progress → Review
```
Unlike general-purpose project management tools, Notion, or issue trackers, PathFlow is designed around personal deep-work execution, deterministic progress velocity, and local-first data ownership.

## 3. Current Development Phase
* **Phase 1: Project Foundation (Active)**
  * Lightweight application shell with responsive navigation
  * Routing and screen placeholders for all 8 target views
  * Clean, decoupled directory structure conforming to layered architectural principles
  * Strict TypeScript configuration
  * Zero premature domain models or mock databases

## 4. Technology Stack
* **Runtime / Framework**: React 19, TypeScript
* **Build Tool**: Vite 8
* **Styling**: Tailwind CSS v4
* **Icons**: Lucide React
* **Testing Foundation**: Node.js test runner with TypeScript execution via `tsx`
* **Architectural Target**: Progressive Web App (PWA) with local IndexedDB persistence (scheduled for Phase 2/3)

## 5. Project Structure
```text
pathflow/
│
├── README.md                 # Project overview and lifecycle guide
├── package.json              # Minimal dependency manifest
├── tsconfig.json             # Strict TypeScript configuration
├── vite.config.ts            # Vite bundler configuration
│
├── src/
│   ├── app/                  # Application orchestration layer
│   │   ├── routes/           # Typed route IDs and route definitions
│   │   ├── providers/        # Lightweight RouterProvider and app context
│   │   └── config/           # Centralized application constants & metadata
│   │
│   ├── components/           # Presentation layout components
│   │   ├── layout/           # AppShell, Sidebar, Header
│   │   └── ui/               # Reusable PlaceholderView
│   │
│   ├── features/             # Feature module UI placeholders
│   │   ├── dashboard/        # Foundation dashboard overview
│   │   ├── goals/            # Goals module placeholder (Phase 2)
│   │   ├── roadmaps/         # Roadmaps module placeholder (Phase 2)
│   │   ├── tasks/            # Tasks module placeholder (Phase 2)
│   │   ├── sessions/         # Work sessions & time tracking placeholder (Phase 3)
│   │   ├── weekly-plans/     # Weekly planning & capacity placeholder (Phase 3)
│   │   ├── progress/         # Progress & velocity placeholder (Phase 3)
│   │   └── teacher/          # Teacher review & sharing placeholder (Phase 4)
│   │
│   ├── domain/               # Pure business domain layer (Phase 2)
│   │   ├── models/           # Domain entity definitions (no UI/DB dependencies)
│   │   ├── services/         # Domain calculation & orchestration services
│   │   └── rules/            # Invariant business rules & validation logic
│   │
│   ├── data/                 # Data access layer (Phase 2/3)
│   │   ├── local/            # Future IndexedDB offline storage adapter
│   │   ├── remote/           # Future remote API client
│   │   └── repositories/     # Repository pattern interfaces & implementations
│   │
│   ├── sync/                 # Synchronization layer (Phase 4)
│   │   ├── queue/            # Persistent outbound mutation queue
│   │   ├── engine/           # Background incremental delta sync engine
│   │   └── conflict/         # Conflict detection & resolution strategies
│   │
│   ├── utils/                # Stateless pure utility functions (e.g., cn.ts)
│   │
│   ├── main.tsx              # Application entry point
│   └── App.tsx               # Root component binding RouterProvider & AppShell
│
├── tests/                    # Test suite
│   ├── unit/                 # Unit tests (includes smoke.test.ts)
│   └── integration/          # Future integration and repository tests
│
├── backend/                  # Future server-side service (PostgreSQL & sync endpoints)
│
└── docs/                     # Architectural documentation
    └── architecture.md       # Detailed layered architectural specification
```

## 6. How to Install Dependencies
Install all project dependencies using npm:
```bash
npm install
```

## 7. How to Run the Development Server
Launch the development server on `http://localhost:3000`:
```bash
npm run dev
```

To run TypeScript verification:
```bash
npm run lint
```

To run smoke tests:
```bash
npx tsx --test tests/unit/smoke.test.ts
```

To compile for production:
```bash
npm run build
```

## 8. Current Limitations
* **No Persistence**: Data is not yet saved to IndexedDB or local storage.
* **No Domain Entities**: Models for Goal, Task, Roadmap, and Session are deliberately omitted until Phase 2 data modeling.
* **Placeholder Screens**: Feature views present structural routing and responsibility scopes only.
* **No Network Sync**: No backend endpoints or remote sync adapters are active in this phase.

## 9. Planned Next Phase
* **Phase 2: Domain Data Modeling & Local Persistence**
  * Define pure TypeScript domain models (Goal, Roadmap, Milestone, Task)
  * Establish domain validation rules and invariants
  * Implement Repository interfaces
  * Configure local IndexedDB persistence adapter
  * Replace feature placeholders for Goals, Roadmaps, and Tasks with interactive views
