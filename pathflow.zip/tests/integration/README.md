# Integration Tests

This directory is reserved for multi-component and cross-layer integration tests.

## Planned Scenarios (Future Phases)
* **Local Persistence Integration**: Testing local database operations against in-memory/mock IndexedDB drivers.
* **Sync Engine & Conflict Resolution**: Simulating offline mutations, reconnects, server delta responses, and conflict merges.
* **Teacher View Data Isolation**: Verifying that mentor snapshot exports only expose permitted progress summaries and redact private raw notes.
