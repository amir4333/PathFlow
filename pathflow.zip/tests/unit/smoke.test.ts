import test from 'node:test';
import assert from 'node:assert/strict';
import { APP_CONFIG } from '../../src/app/config/appConfig.ts';
import { APP_ROUTES } from '../../src/app/routes/routes.ts';
import { cn } from '../../src/utils/cn.ts';

test('PathFlow smoke test: APP_CONFIG has valid metadata', () => {
  assert.equal(APP_CONFIG.name, 'PathFlow');
  assert.equal(APP_CONFIG.version, '0.1.0');
  assert.equal(APP_CONFIG.coreWorkflow.length, 7);
  assert.deepEqual(Array.from(APP_CONFIG.coreWorkflow), [
    'Goal',
    'Roadmap',
    'Task',
    'Session',
    'Time',
    'Progress',
    'Review',
  ]);
});

test('PathFlow smoke test: All 8 initial navigation routes are defined', () => {
  const expectedRouteIds = [
    'dashboard',
    'goals',
    'roadmaps',
    'tasks',
    'sessions',
    'weekly-plans',
    'progress',
    'teacher',
  ];

  assert.equal(APP_ROUTES.length, 8);
  const registeredIds = APP_ROUTES.map((r) => r.id);
  assert.deepEqual(registeredIds, expectedRouteIds);
});

test('PathFlow smoke test: cn utility handles truthy, falsy, and conditional classes', () => {
  assert.equal(cn('base-class', false && 'hidden', 'active'), 'base-class active');
  assert.equal(cn('px-4', undefined, null, 'py-2'), 'px-4 py-2');
});
