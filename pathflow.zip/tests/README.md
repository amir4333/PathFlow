# PathFlow Test Suite

This directory is organized to support test-driven development and verification across layers without restructuring the codebase.

## Directory Structure
* `tests/unit/`: Unit tests for domain models, rules, services, utilities, and isolated pure functions.
* `tests/integration/`: Integration tests for local repositories, IndexedDB adapters, synchronization engine queues, and end-to-end component flows.

## Philosophy
* **Pure Domain Testing**: Domain models and business rules are pure TypeScript, testable without DOM or browser mocks.
* **Repository Mocking**: Repository interfaces enable fast in-memory unit and integration tests without physical IndexedDB or network dependencies.
